package com.linln.component.actionLog.config;

import org.springframework.context.annotation.ComponentScan;

/**
 * @author 小懒虫 <auntvt＠163.com>
 * @date 2021/3/19
 */
@ComponentScan(basePackages = "com.linln.component.actionLog")
public class ActionLogAutoConfig {
}
